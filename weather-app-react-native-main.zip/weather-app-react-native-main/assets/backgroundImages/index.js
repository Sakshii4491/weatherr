const haze = require('./img/haze.jpg');
const rainy = require('./img/rainy.jpg');
const snow = require('./img/snow.jpg');
const sunny = require('./img/sunny.jpg');

export { haze, rainy, snow, sunny };